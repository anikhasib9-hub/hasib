# আমার দোকান — Android Project

এটি তোমার দোকানের অর্ডার, ডেলিভারি ও হিসাবের প্রথম Android source/demo।

## বর্তমান ডেমো ফিচার
- ড্যাশবোর্ড
- রিসিট/ফোন/কোড সার্চ
- সবুজ = ডেলিভারি হয়েছে, লাল = দোকানে আছে
- ক্যালেন্ডার
- দৈনিক হিসাব
- অর্ডার/ডেলিভারি/খরচ/আমদানি এন্ট্রি ফর্ম
- মোট আয়, আমদানি, ব্যয়, লাভ ও বাকি
- Android ফোনের জন্য Jetpack Compose UI

## গুরুত্বপূর্ণ
এই প্রথম source version-এ ডাটা in-memory demo হিসেবে আছে। আসল production version-এ Room/SQLite database যোগ করে একই ডাটা সব screen-এ sync করতে হবে। তারপর backup/sync এবং PDF/প্রিন্ট ফিচার যোগ করা যাবে।

## Android Studio-তে চালানো
1. Android Studio-তে এই project folder খুলুন।
2. Gradle sync হতে দিন।
3. Android emulator বা ফোন নির্বাচন করুন।
4. Run চাপুন।
