package com.amardokan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val Green = Color(0xFF087A45)
private val Red = Color(0xFFD62828)
private val Blue = Color(0xFF1769AA)
private val Bg = Color(0xFFF4F7F5)

data class Receipt(
    val number: String,
    val phone: String,
    val name: String,
    val amount: Int,
    val delivered: Boolean
)

private val demoReceipts = listOf(
    Receipt("CN-000123", "01712-345678", "আমিনুর রহমান", 2450, true),
    Receipt("CN-000124", "01819-223344", "সাবিনা", 1870, true),
    Receipt("CN-000125", "01911-556677", "রাকিব", 3250, false),
    Receipt("CN-000126", "01655-778899", "জাহিদ", 2100, false)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmarDokanApp() }
    }
}

@Composable
fun AmarDokanApp() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Green,
            background = Bg
        )
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    listOf("হোম", "অর্ডার", "তারিখ", "দৈনিক", "হিসাব").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(listOf("🏠","🧾","📅","📊","💰")[i]) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize().background(Bg)) {
                when (tab) {
                    0 -> Dashboard(onNavigate = { tab = it })
                    1 -> Orders()
                    2 -> CalendarPage()
                    3 -> DailyPage()
                    4 -> Accounts()
                }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(
        Modifier.fillMaxWidth().background(Green).padding(18.dp)
    ) {
        Text(title, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Color.White.copy(alpha=.85f), fontSize = 14.sp)
    }
}

@Composable
fun StatCard(title: String, value: String, color: Color = Color.DarkGray) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 15.sp)
            Text(value, fontSize = 23.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun Dashboard(onNavigate: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("আমার দোকান", "অর্ডার • হিসাব • স্টক")
        LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { StatCard("মোট অর্ডার", "১২৫") }
                    Box(Modifier.weight(1f)) { StatCard("ডেলিভারি", "৯৮", Blue) }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.weight(1f)) { StatCard("দোকানে আছে", "২৭", Red) }
                    Box(Modifier.weight(1f)) { StatCard("আজকের বিক্রি", "৳ ১৮,৭৫০", Green) }
                }
            }
            item { Text("দ্রুত কাজ", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onNavigate(1) }, Modifier.weight(1f)) { Text("🔎 রিসিট খুঁজুন") }
                    Button(onClick = { onNavigate(2) }, Modifier.weight(1f)) { Text("📅 তারিখ") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onNavigate(3) }, Modifier.weight(1f)) { Text("📊 দৈনিক") }
                    Button(onClick = { onNavigate(4) }, Modifier.weight(1f)) { Text("💰 ট্যালি") }
                }
            }
        }
    }
}

@Composable
fun Orders() {
    var query by remember { mutableStateOf("") }
    val filtered = demoReceipts.filter {
        "${it.number} ${it.phone} ${it.name}".contains(query, ignoreCase = true)
    }
    Column(Modifier.fillMaxSize()) {
        Header("অর্ডার / রিসিট")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            label = { Text("ফোন / রিসিট / কোড সার্চ") },
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            singleLine = true
        )
        LazyColumn(Modifier.padding(horizontal = 14.dp)) {
            items(filtered) { r ->
                Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).background(if (r.delivered) Color(0xFF19A85A) else Color(0xFFE53935), RoundedCornerShape(50)))
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(r.number, fontWeight = FontWeight.Bold)
                            Text("${r.name} • ${r.phone}", fontSize = 13.sp)
                            Text(if (r.delivered) "ডেলিভারি হয়েছে" else "এখনো দোকানে",
                                color = if (r.delivered) Green else Red, fontSize = 13.sp)
                        }
                        Text("৳ ${r.amount}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarPage() {
    var selected by remember { mutableIntStateOf(12) }
    Column(Modifier.fillMaxSize()) {
        Header("ক্যালেন্ডার", "তারিখ অনুযায়ী অর্ডার ও হিসাব")
        Card(Modifier.padding(14.dp)) {
            Column(Modifier.padding(14.dp)) {
                Text("মে ২০২৪", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("রবি","সোম","মঙ্গল","বুধ","বৃহস্পতি","শুক্র","শনি").forEach { Text(it, fontSize = 11.sp) }
                }
                Spacer(Modifier.height(6.dp))
                for (week in 0..4) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        for (i in 1..7) {
                            val d = week * 7 + i
                            if (d <= 31) {
                                Text(
                                    d.toString(),
                                    Modifier.padding(8.dp).clickable { selected = d },
                                    color = if (selected == d) Green else Color.DarkGray,
                                    fontWeight = if (selected == d) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
        Card(Modifier.padding(horizontal = 14.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("$selected মে ২০২৪", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("অর্ডার পড়েছে: ১৪টি")
                Text("ডেলিভারি হয়েছে: ১১টি", color = Green)
                Text("দোকানে আছে: ৩টি", color = Red)
                Text("মোট বিক্রি: ৳ ১৮,৭৫০", color = Green)
            }
        }
    }
}

@Composable
fun DailyPage() {
    var show by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize()) {
        Header("দৈনিক হিসাব")
        LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { StatCard("নতুন অর্ডার", "১৪") }
            item { StatCard("ডেলিভারি গেছে", "১১", Green) }
            item { StatCard("দোকানে আছে", "৩", Red) }
            item { StatCard("মোট আয়", "৳ ১৮,৭৫০", Green) }
            item { StatCard("আজকের খরচ", "৳ ১,৮৫০", Red) }
            item { Text("দৈনিক এন্ট্রি", fontSize = 19.sp, fontWeight = FontWeight.Bold) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { show = "অর্ডার এন্ট্রি" }, Modifier.weight(1f)) { Text("🧾 অর্ডার") }
                    Button(onClick = { show = "ডেলিভারি এন্ট্রি" }, Modifier.weight(1f)) { Text("🚚 ডেলিভারি") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { show = "খরচ এন্ট্রি" }, Modifier.weight(1f)) { Text("💸 খরচ") }
                    Button(onClick = { show = "আমদানি এন্ট্রি" }, Modifier.weight(1f)) { Text("📦 আমদানি") }
                }
            }
            if (show != null) item { EntryForm(title = show!!) }
            item { Text("এই ডাটা পরে ড্যাশবোর্ড, ক্যালেন্ডার, হিসাব ও রিপোর্টে একই ডাটাবেস থেকে ব্যবহার হবে।", fontSize = 13.sp) }
        }
    }
}

@Composable
fun EntryForm(title: String) {
    var receipt by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            if (title.contains("অর্ডার") || title.contains("ডেলিভারি")) {
                OutlinedTextField(receipt, { receipt = it }, label = { Text("রিসিট নম্বর") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(phone, { phone = it }, label = { Text("ফোন নম্বর") }, modifier = Modifier.fillMaxWidth())
            }
            OutlinedTextField(amount, { amount = it }, label = { Text("টাকার পরিমাণ") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { saved = true }) { Text("✓ এন্ট্রি সেভ করুন") }
            if (saved) Text("✓ ডেমো এন্ট্রি সেভ হয়েছে", color = Green)
        }
    }
}

@Composable
fun Accounts() {
    Column(Modifier.fillMaxSize()) {
        Header("হিসাব / ট্যালি")
        LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { StatCard("মোট বিক্রি / আয়", "৳ ১৮,৭৫০", Green) }
            item { StatCard("মোট আমদানি", "৳ ১২,৩০০", Blue) }
            item { StatCard("মোট ব্যয়", "৳ ১,৮৫০", Red) }
            item { StatCard("লাভ", "৳ ৪,৬০০", Green) }
            item { StatCard("বাকি টাকা", "৳ ২,৪৫০", Red) }
            item { Text("একই ডাটা দিয়ে দৈনিক, মাসিক ও নির্দিষ্ট তারিখের রিপোর্ট তৈরি করা যাবে।", fontSize = 14.sp) }
        }
    }
}
