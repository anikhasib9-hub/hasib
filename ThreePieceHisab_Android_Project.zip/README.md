# থ্রি-পিস হিসাব — Android Project

এটি আপনার দর্জি দোকানের জন্য তৈরি একটি ছোট Android অ্যাপের project।

ফিচার:
- অটো ক্রমিক নম্বর
- কাস্টমারের নাম
- থ্রি-পিস সংখ্যা
- মোট/অগ্রিম/বাকি টাকা
- ডেলিভারি স্ট্যাটাস
- ডেলিভারি না হলে 🔴 লাল ক্রমিক নম্বর
- ডেলিভারি হলে 🟢 সবুজ ক্রমিক নম্বর
- ফোনের SharedPreferences-এ ডাটা সংরক্ষণ

## APK বানানো
Android Studio-তে project folder খুলুন। Gradle sync শেষ হলে:
Build > Build Bundle(s) / APK(s) > Build APK(s)

তারপর debug APK পাওয়া যাবে:
app/build/outputs/apk/debug/app-debug.apk

নোট: এই ZIP-এ Gradle wrapper নেই; Android Studio-এর installed Gradle/AGP support ব্যবহার করে project খুলুন।
