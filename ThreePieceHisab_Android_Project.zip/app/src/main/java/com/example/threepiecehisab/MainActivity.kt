package com.example.threepiecehisab

import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Order(
    val id: Int,
    val customer: String,
    val pieces: Int,
    val total: Double,
    val advance: Double,
    var delivered: Boolean,
    val date: String
) {
    val due: Double get() = total - advance
}

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private val orders = mutableListOf<Order>()
    private val prefs by lazy { getSharedPreferences("orders", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20,20,20,20)
        }
        summary = TextView(this).apply { textSize=18f; setPadding(8,8,8,16) }
        root.addView(summary)

        val add = Button(this).apply { text = "➕ নতুন অর্ডার" }
        add.setOnClickListener { showAddDialog() }
        root.addView(add)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
    }

    private fun showAddDialog() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(30,10,30,0) }
        val name = EditText(this).apply { hint="কাস্টমারের নাম" }
        val pieces = EditText(this).apply { hint="থ্রি-পিস সংখ্যা"; inputType=2 }
        val total = EditText(this).apply { hint="মোট টাকা"; inputType=2 or 8192 }
        val advance = EditText(this).apply { hint="অগ্রিম টাকা"; inputType=2 or 8192 }
        box.addView(name); box.addView(pieces); box.addView(total); box.addView(advance)

        AlertDialog.Builder(this).setTitle("নতুন অর্ডার").setView(box)
            .setPositiveButton("সংরক্ষণ") { _, _ ->
                val n=name.text.toString().trim()
                val p=pieces.text.toString().toIntOrNull() ?: 0
                val t=total.text.toString().toDoubleOrNull() ?: 0.0
                val a=advance.text.toString().toDoubleOrNull() ?: 0.0
                if(n.isNotEmpty() && p>0) {
                    orders.add(Order(nextId(),n,p,t,a,false,today()))
                    save(); refresh()
                }
            }.setNegativeButton("বাতিল", null).show()
    }

    private fun nextId() = (orders.maxOfOrNull { it.id } ?: 0) + 1
    private fun today() = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

    private fun refresh() {
        list.removeAllViews()
        val delivered=orders.count{it.delivered}
        val pieces=orders.sumOf{it.pieces}
        val money=orders.filter{it.delivered}.sumOf{it.total}
        summary.text="আজ/মোট অর্ডার: ${orders.size}   |   থ্রি-পিস: $pieces\nডেলিভারি: $delivered   |   ডেলিভারি টাকা: ৳${money.toInt()}"
        orders.sortedByDescending{it.id}.forEach { o ->
            val row=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL
                setPadding(12,12,12,12)
                setBackgroundColor(if(o.delivered) Color.rgb(232,245,233) else Color.rgb(255,235,238))
            }
            val title=TextView(this).apply {
                text=String.format("%03d — %s",o.id,o.customer)
                textSize=19f; setTextColor(if(o.delivered) Color.rgb(0,128,0) else Color.RED)
            }
            val detail=TextView(this).apply {
                text="থ্রি-পিস: ${o.pieces} | মোট: ৳${o.total.toInt()} | অগ্রিম: ৳${o.advance.toInt()} | বাকি: ৳${o.due.toInt()}\nতারিখ: ${o.date}"
                textSize=15f
            }
            val btn=Button(this).apply { text=if(o.delivered) "ডেলিভারি হয়েছে — বাতিল করুন" else "ডেলিভারি দিন" }
            btn.setOnClickListener {
                o.delivered=!o.delivered; save(); refresh()
            }
            row.addView(title); row.addView(detail); row.addView(btn)
            val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,12)
            list.addView(row,lp)
        }
    }

    private fun save() {
        val arr=JSONArray()
        orders.forEach { o ->
            arr.put(JSONObject().apply {
                put("id",o.id); put("customer",o.customer); put("pieces",o.pieces)
                put("total",o.total); put("advance",o.advance); put("delivered",o.delivered); put("date",o.date)
            })
        }
        prefs.edit().putString("data",arr.toString()).apply()
    }

    private fun load() {
        val s=prefs.getString("data",null) ?: return
        runCatching {
            val arr=JSONArray(s)
            for(i in 0 until arr.length()) {
                val x=arr.getJSONObject(i)
                orders.add(Order(x.getInt("id"),x.getString("customer"),x.getInt("pieces"),
                    x.getDouble("total"),x.getDouble("advance"),x.getBoolean("delivered"),x.getString("date")))
            }
        }
    }
}
